

```bash
# Clone this repository
git clone 
# Go into the repository
cd blockeduc-master
# Install dependencies
npm install
# Run the app
npm start
```
