# blockeduc
