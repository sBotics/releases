var toolbox = '<xml>';
toolbox += '<category name="Lógica" colour="210">';
toolbox += '<block type="start" deletable="false" movable="false"></block>';
toolbox += '<block type="controls_if"></block>';
toolbox += '<block type="enquanto_farei"></block>';
toolbox += '<block type="enquanto_farei"></block>';
toolbox += '</xml>';